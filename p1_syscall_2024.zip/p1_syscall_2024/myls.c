//P1-SSOO-23/24

#include <stdio.h>		// Header file for system call printf
#include <unistd.h>		// Header file for system call gtcwd
#include <sys/types.h>	// Header file for system calls opendir, readdir y closedir
#include <dirent.h>
#include <string.h>
#define PATH_MAX 4096

int myls(const char *dirname){
    DIR *direct;
    if(dirname!=NULL){
        direct= opendir(dirname);
    }else{
        char buffer[PATH_MAX]; // Buffer para almacenar el directorio
            if (getcwd(buffer, sizeof(buffer)) == NULL) {
                perror("getcwd");
                return -1;
            }
            direct = opendir(buffer);
    }
    struct dirent *entry;
    while ((entry = readdir(direct)) != NULL){
        printf("%s\n", entry->d_name);
    }
    closedir(direct);
}

int main(int argc, char *argv[])
{
  if (argc == 1){
     myls(NULL);
   }  
  else if (argc == 2){
    myls(argv[1]);
  }
	return 0;
}

